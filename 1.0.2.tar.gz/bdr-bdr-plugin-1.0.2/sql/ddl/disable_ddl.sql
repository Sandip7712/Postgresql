ALTER DATABASE regression RESET bdr.permit_ddl_locking;
ALTER DATABASE postgres RESET bdr.permit_ddl_locking;
