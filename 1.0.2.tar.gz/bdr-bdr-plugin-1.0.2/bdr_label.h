/*
 * bdr_label.h
 *
 * BiDirectionalReplication
 *
 * Copyright (c) 2014-2015, PostgreSQL Global Development Group
 *
 * bdr_label.h
 */

#define BDR_SECLABEL_PROVIDER "bdr"

extern void bdr_label_init(void);
