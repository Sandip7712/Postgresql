/*
 * These are defined in pg_config.h so we have to undef them to get rid of
 * redefine warnings.
 */
#undef PACKAGE_BUGREPORT
#undef PACKAGE_NAME
#undef PACKAGE_STRING
#undef PACKAGE_TARNAME
#undef PACKAGE_URL
#undef PACKAGE_VERSION

#include "bdr_config_generated.h"
