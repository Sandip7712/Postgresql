autoreconf -f
